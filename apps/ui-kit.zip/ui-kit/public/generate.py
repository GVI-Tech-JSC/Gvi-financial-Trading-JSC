#!/usr/bin/env python3
"""
GVI-JSC Brand Kit v2.5 — Asset Generator  (căn chỉnh chuẩn v2)
Xuất toàn bộ logo SVG, PNG, WebP vào thư mục asset/img/
Yêu cầu: rsvg-convert (librsvg2-bin)

Taurus ♉ symbol bounding-box (stroke=24, scale=1):
  Path horns : M22 28 C22 48,36 52,50 52 C64 52,78 48,78 28
  Circle     : cx=50 cy=64 r=21
  Geometric centre (no stroke) : cx=50  cy=56.5
  Stroke bbox (stroke_out=24)  : x=[10,90] y=[16,97]  →  80×81 units
  → để đặt tâm tại (CX,CY): translate(CX - 50·s, CY - 56.5·s)  scale(s)
"""
import os, subprocess, shutil

OUT   = os.path.dirname(os.path.abspath(__file__))
SVG_D = os.path.join(OUT, "svg")
os.makedirs(SVG_D, exist_ok=True)

# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

FONT_EMBED = """<defs>
  <style>
    .bt { font-family: 'Inter', system-ui, Arial, sans-serif;
          font-weight: 900; letter-spacing: -1px; }
  </style>
</defs>"""


def _taurus_paths(sc, tx, ty, stroke_out, stroke_in,
                  fill_color, outline_color, shadow_color, show_shadow=True):
    """
    SVG markup cho biểu tượng Kim Ngưu ♉.
    Tất cả toạ độ render = (native_coord × sc) + translate(tx, ty).
    Geometric center của symbol (stroke bbox) tại tx+50·sc, ty+56.5·sc.
    """
    so, si = stroke_out, stroke_in
    horns = "M22 28 C22 48,36 52,50 52 C64 52,78 48,78 28"
    shadow = ""
    if show_shadow:
        # shadow offset = (4·sc, 5·sc) trong không gian canvas
        sdx = round(tx + 4 * sc, 3)
        sdy = round(ty + 5 * sc, 3)
        shadow = f"""
  <g transform="translate({sdx},{sdy}) scale({sc})" opacity="0.45">
    <path d="{horns}" fill="none" stroke="{shadow_color}"
          stroke-width="{so}" stroke-linecap="round"/>
    <circle cx="50" cy="64" r="21" fill="none" stroke="{shadow_color}" stroke-width="{so}"/>
    <path d="{horns}" fill="none" stroke="{shadow_color}"
          stroke-width="{si}" stroke-linecap="round"/>
    <circle cx="50" cy="64" r="21" fill="none" stroke="{shadow_color}" stroke-width="{si}"/>
  </g>"""
    tx_r = round(tx, 3); ty_r = round(ty, 3); sc_r = round(sc, 4)
    main = f"""
  <g transform="translate({tx_r},{ty_r}) scale({sc_r})">
    <path d="{horns}" fill="none" stroke="{outline_color}"
          stroke-width="{so}" stroke-linecap="round"/>
    <circle cx="50" cy="64" r="21" fill="none" stroke="{outline_color}" stroke-width="{so}"/>
    <path d="{horns}" fill="none" stroke="{fill_color}"
          stroke-width="{si}" stroke-linecap="round"/>
    <circle cx="50" cy="64" r="21" fill="none" stroke="{fill_color}" stroke-width="{si}"/>
  </g>"""
    return shadow + main


def _place_symbol_at(cx, cy, scale,
                     fill="#FCB712", outline="#1C1D1F", shadow="#1C1D1F",
                     stroke_out=24, stroke_in=14, show_shadow=True):
    """
    Đặt biểu tượng sao cho tâm hình học (50, 56.5) khớp với (cx, cy) canvas.
    """
    tx = cx - 50 * scale
    ty = cy - 56.5 * scale
    return _taurus_paths(scale, tx, ty, stroke_out, stroke_in,
                         fill, outline, shadow, show_shadow)


# ─────────────────────────────────────────────────────────────────────────────
# SVG GENERATORS  — mọi shape đều căn chỉnh toán học
# ─────────────────────────────────────────────────────────────────────────────

def logo_horizontal(text="GVI-JSC", fill="#FCB712", outline="#1C1D1F",
                    text_color="#F3F4F6", bg=None,
                    canvas_w=480, canvas_h=130):
    """
    Logo ngang: symbol bên trái, chữ bên phải.
    Symbol vertical center = canvas_h/2.
    Symbol scale=1 → stroke-bbox 80×81; đặt tại x=56 (left pad 16 + stroke-bleed 10),
    text_x = symbol right edge + 14px gap.
    """
    sc = 1.0
    sym_cx = 56.0                          # tâm ngang của symbol
    sym_cy = canvas_h / 2                  # tâm dọc = giữa canvas
    text_x = sym_cx + 50 * sc + 14        # = right stroke-edge (40) + 14 ≈ 110
    # font-size: 72% của canvas_h, baseline ở 66% canvas_h
    font_size = round(canvas_h * 0.72)
    text_y    = round(canvas_h * 0.695)
    bg_rect = f'<rect width="{canvas_w}" height="{canvas_h}" fill="{bg}"/>' if bg else ""
    sym = _place_symbol_at(sym_cx, sym_cy, sc, fill, outline, outline)
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {canvas_w} {canvas_h}" width="{canvas_w}" height="{canvas_h}">
{FONT_EMBED}
  {bg_rect}
  {sym}
  <text x="{text_x}" y="{text_y}" class="bt" font-size="{font_size}" fill="{text_color}">{text}</text>
</svg>"""


def logo_square(text="GVI-JSC", fill="#FCB712", outline="#1C1D1F",
                text_color="#F3F4F6", bg=None, canvas_s=400):
    """
    Logo vuông: symbol ở 40% từ trên, chữ ở 77%.
    Cả hai đều căn giữa theo trục X.
    """
    sc      = 1.8
    sym_cx  = canvas_s / 2
    sym_cy  = canvas_s * 0.40
    text_y  = round(canvas_s * 0.77)
    font_s  = round(canvas_s * 0.145)
    bg_rect = f'<rect width="{canvas_s}" height="{canvas_s}" fill="{bg}"/>' if bg else ""
    sym     = _place_symbol_at(sym_cx, sym_cy, sc, fill, outline, outline)
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {canvas_s} {canvas_s}" width="{canvas_s}" height="{canvas_s}">
{FONT_EMBED}
  {bg_rect}
  {sym}
  <text x="{sym_cx}" y="{text_y}" class="bt" font-size="{font_s}" fill="{text_color}" text-anchor="middle">{text}</text>
</svg>"""


def logo_appicon(fill="#FCB712", outline="#1C1D1F", bg="#1C1D1F",
                 size=300, rx=68):
    """App icon: symbol căn chính giữa hoàn toàn, coverage=55%."""
    sc     = size * 0.55 / 80   # 80 = stroke-bbox width
    sym_cx = size / 2
    sym_cy = size / 2
    sym    = _place_symbol_at(sym_cx, sym_cy, sc, fill, outline, outline)
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {size} {size}" width="{size}" height="{size}">
{FONT_EMBED}
  <rect width="{size}" height="{size}" rx="{rx}" fill="{bg}"/>
  {sym}
</svg>"""


def logo_appicon_round(fill="#FCB712", outline="#1C1D1F", bg="#1C1D1F", size=300):
    """App icon tròn (iOS / PWA maskable): clip = circle."""
    sc     = size * 0.55 / 80
    sym_cx = size / 2
    sym_cy = size / 2
    sym    = _place_symbol_at(sym_cx, sym_cy, sc, fill, outline, outline)
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {size} {size}" width="{size}" height="{size}">
{FONT_EMBED}
  <defs><clipPath id="cp"><circle cx="{size//2}" cy="{size//2}" r="{size//2}"/></clipPath></defs>
  <rect width="{size}" height="{size}" fill="{bg}" clip-path="url(#cp)"/>
  <g clip-path="url(#cp)">{sym}</g>
</svg>"""


def logo_emoji(fill="#FCB712", outline="#1C1D1F", size=200):
    """Emoji: symbol thuần, căn giữa, không nền."""
    sc     = size * 0.55 / 80
    sym_cx = size / 2
    sym_cy = size / 2
    sym    = _place_symbol_at(sym_cx, sym_cy, sc, fill, outline, outline, show_shadow=False)
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {size} {size}" width="{size}" height="{size}">
  {sym}
</svg>"""


def token_icon(token_name, bg_color, inner_color, outline_color, text_color, size=512):
    """
    Token icon hình tròn: symbol + text label.

    Layout (căn chỉnh toán học — KHÔNG chồng lấp):
      symbol + gap + text_cap_height  =  1 block dọc
      block được căn optical-center (canvas_mid - 1.6%) của canvas.
      sc = diam*0.44/80  →  symbol chiếm 44% đường kính circle.
      gap = 3.9% of size (~20px tại 512).
    """
    r        = int(size * 0.46)
    diam     = r * 2                      # 470px tại size=512

    sc       = diam * 0.44 / 80          # stroke-bbox width (80u) chiếm 44% diam
    H_sym    = 81 * sc                   # chiều cao stroke-bbox
    fs       = round(size * 0.155)       # font-size ~79px
    H_cap    = fs * 0.72                 # cap-height xấp xỉ
    gap      = size * 0.039              # ~20px tại size=512

    total_h  = H_sym + gap + H_cap
    opt_cy   = size / 2 - size * 0.016  # optical center hơi lên

    # Tâm symbol = phần trên của block
    sym_cy   = opt_cy - total_h / 2 + H_sym / 2
    sym_cx   = size / 2

    # Baseline text = phần dưới của block
    text_y   = round(sym_cy + H_sym / 2 + gap + H_cap)

    sym      = _place_symbol_at(sym_cx, sym_cy, sc,
                                fill=inner_color,
                                outline=outline_color,
                                shadow=outline_color,
                                stroke_out=round(24 * 0.92),
                                stroke_in=round(14 * 0.92))
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {size} {size}" width="{size}" height="{size}">
{FONT_EMBED}
  <circle cx="{size//2}" cy="{size//2}" r="{r}" fill="{bg_color}"/>
  <circle cx="{size//2}" cy="{size//2}" r="{r}" fill="none"
          stroke="{outline_color}" stroke-width="{round(size*0.035)}"/>
  {sym}
  <text x="{size//2}" y="{text_y}" class="bt"
        font-size="{fs}" fill="{text_color}" text-anchor="middle">{token_name}</text>
</svg>"""


# ─────────────────────────────────────────────────────────────────────────────
# ASSET DEFINITIONS
# ─────────────────────────────────────────────────────────────────────────────

SVGS = {
    "logo-horizontal-dark":        logo_horizontal(fill="#FCB712", outline="#1C1D1F", text_color="#F3F4F6", bg="#1C1D1F"),
    "logo-horizontal-light":       logo_horizontal(fill="#FCB712", outline="#1C1D1F", text_color="#1C1D1F", bg="#FFFFFF"),
    "logo-horizontal-transparent": logo_horizontal(fill="#FCB712", outline="#1C1D1F", text_color="#F3F4F6"),
    "logo-horizontal-neon":        logo_horizontal(fill="#FFE05D", outline="#0C0A09", text_color="#FFFFFF",  bg="#1e1b4b"),
    "logo-square-dark":            logo_square(fill="#FCB712", outline="#1C1D1F", text_color="#F3F4F6", bg="#1C1D1F"),
    "logo-square-light":           logo_square(fill="#FCB712", outline="#1C1D1F", text_color="#1C1D1F", bg="#FFFFFF"),
    "logo-appicon":                logo_appicon(),
    "logo-appicon-round":          logo_appicon_round(),
    "logo-emoji":                  logo_emoji(),
    "token-gvi":                   token_icon("GVI",  "#FCB712", "#1C1D1F", "#1C1D1F", "#1C1D1F"),
    "token-sgvi":                  token_icon("sGVI", "#3B82F6", "#93C5FD", "#1E3A5F", "#FFFFFF"),
    "token-ggvi":                  token_icon("gGVI", "#7C5CD8", "#C4B5FD", "#3B0764", "#FFFFFF"),
    "token-igvi":                  token_icon("iGVI", "#EF4444", "#FCA5A5", "#7F1D1D", "#FFFFFF"),
}

# (filename, svg_key, width, height, bg_for_rsvg)
#  bg_for_rsvg=None  →  transparent / giữ nguyên SVG background
EXPORTS = [
    # ── Favicon System ──────────────────────────────────────────────────────
    ("favicon-16x16",            "logo-appicon",       16,   16),
    ("favicon-32x32",            "logo-appicon",       32,   32),
    ("favicon-48x48",            "logo-appicon",       48,   48),
    ("favicon-96x96",            "logo-appicon",       96,   96),
    ("favicon-144x144",          "logo-appicon",      144,  144),
    ("favicon-192x192",          "logo-appicon-round",192,  192),
    ("favicon-512x512",          "logo-appicon-round",512,  512),
    ("apple-touch-icon-180",     "logo-appicon",      180,  180),
    ("ms-tile-144x144",          "logo-appicon",      144,  144),
    # ── Social / OG ─────────────────────────────────────────────────────────
    ("og-image-1200x630",        "logo-horizontal-dark", 1200, 630),
    ("twitter-card-800x418",     "logo-horizontal-dark",  800, 418),
    # ── Logo ────────────────────────────────────────────────────────────────
    ("logo",                     "logo-horizontal-light",  300,  90),
    ("logo-dark",                "logo-horizontal-dark",   300,  90),
    # ── Token icons ─────────────────────────────────────────────────────────
    ("token-gvi-64",             "token-gvi",    64,   64),
    ("token-gvi-128",            "token-gvi",   128,  128),
    ("token-gvi-256",            "token-gvi",   256,  256),
    ("token-sgvi-64",            "token-sgvi",   64,   64),
    ("token-sgvi-256",           "token-sgvi",  256,  256),
    ("token-ggvi-64",            "token-ggvi",   64,   64),
    ("token-ggvi-256",           "token-ggvi",  256,  256),
    ("token-igvi-64",            "token-igvi",   64,   64),
    ("token-igvi-256",           "token-igvi",  256,  256),
]

# ─────────────────────────────────────────────────────────────────────────────
# RENDER
# ─────────────────────────────────────────────────────────────────────────────

def write_svg(name, content):
    path = os.path.join(SVG_D, f"{name}.svg")
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return path


def rsvg_render(svg_path, png_path, width, height):
    """
    Render SVG → PNG tại đúng kích thước yêu cầu.
    KHÔNG dùng --keep-aspect-ratio để đảm bảo canvas fill đúng.
    SVG đã có viewBox khớp tỷ lệ → không bị méo.
    """
    subprocess.run([
        "rsvg-convert",
        "-w", str(width),
        "-h", str(height),
        "-o", png_path,
        svg_path
    ], check=True, capture_output=True)


def png_to_webp(src_png, dst_webp):
    cwebp = shutil.which("cwebp")
    if cwebp:
        subprocess.run([cwebp, "-lossless", "-q", "100", src_png, "-o", dst_webp],
                       check=True, capture_output=True)
    else:
        shutil.copy2(src_png, dst_webp)


def main():
    import time
    t0 = time.time()
    print("╔══════════════════════════════════════════════════╗")
    print("║  GVI-JSC Brand Kit v2.5  —  Asset Export v2     ║")
    print("╚══════════════════════════════════════════════════╝")
    print(f"  Output → {OUT}\n")

    # Step 1: write SVG sources
    svg_paths = {}
    for name, content in SVGS.items():
        svg_paths[name] = write_svg(name, content)
    print(f"[1/3] SVG sources: {len(svg_paths)} files  →  svg/\n")

    # Step 2 & 3: render PNG + WebP
    ok = err = 0
    for (fname, src_key, w, h) in EXPORTS:
        svg_src  = svg_paths[src_key]
        out_png  = os.path.join(OUT, f"{fname}.png")
        out_webp = os.path.join(OUT, f"{fname}.webp")
        try:
            rsvg_render(svg_src, out_png, w, h)
            png_to_webp(out_png, out_webp)
            kb_png  = max(1, os.path.getsize(out_png)  // 1024)
            kb_webp = max(1, os.path.getsize(out_webp) // 1024)
            print(f"  ✔  {fname:42s}  {w:>4}×{h:<4}  PNG {kb_png:>3}kB  WebP {kb_webp:>3}kB")
            ok += 1
        except subprocess.CalledProcessError as e:
            print(f"  ✘  {fname:42s}  FAILED: {e.stderr.decode()[:100]}")
            err += 1

    elapsed = round(time.time() - t0, 2)
    total   = len(SVGS) + ok * 2
    print(f"\n{'─'*60}")
    print(f"  SVG : {len(SVGS):3d} files")
    print(f"  PNG : {ok:3d} files")
    print(f"  WebP: {ok:3d} files")
    if err: print(f"  ERR : {err:3d} files")
    print(f"  Total: ~{total} files  |  {elapsed}s")
    print(f"  Dir  : {OUT}")
    print("╚══════════════════════════════════════════════════╝")


if __name__ == "__main__":
    main()
