# GVI-JSC Brand Kit v2.5 — Asset Directory

> Thương hiệu Kim Ngưu ♉ · HOT Protocol & HERE Wallet style  
> Tự động sinh bởi `generate.py` — **57 files**, tổng ~500 KB

---

## 📁 Cấu trúc thư mục

```
asset/img/
├── svg/                          # Vector sources (13 files)
│   ├── logo-horizontal-dark.svg
│   ├── logo-horizontal-light.svg
│   ├── logo-horizontal-transparent.svg
│   ├── logo-horizontal-neon.svg
│   ├── logo-square-dark.svg
│   ├── logo-square-light.svg
│   ├── logo-appicon.svg
│   ├── logo-appicon-round.svg
│   ├── logo-emoji.svg
│   ├── token-gvi.svg
│   ├── token-sgvi.svg
│   ├── token-ggvi.svg
│   └── token-igvi.svg
│
├── ── Logo (PNG + WebP) ──────────────────────────
│   ├── logo.png / logo.webp              300×90  Light bg
│   └── logo-dark.png / logo-dark.webp   300×90  Dark bg
│
├── ── Favicon System ─────────────────────────────
│   ├── favicon-16x16.png/webp
│   ├── favicon-32x32.png/webp
│   ├── favicon-48x48.png/webp
│   ├── favicon-96x96.png/webp
│   ├── favicon-144x144.png/webp
│   ├── favicon-192x192.png/webp          PWA maskable
│   ├── favicon-512x512.png/webp          PWA maskable
│   ├── apple-touch-icon-180.png/webp
│   └── ms-tile-144x144.png/webp
│
├── ── Social / OG ────────────────────────────────
│   ├── og-image-1200x630.png/webp        Open Graph
│   └── twitter-card-800x418.png/webp     Twitter Card
│
└── ── Token Icons ────────────────────────────────
    ├── token-gvi-64.png/webp             GVI  (amber)
    ├── token-gvi-128.png/webp
    ├── token-gvi-256.png/webp
    ├── token-sgvi-64.png/webp            sGVI (blue)
    ├── token-sgvi-256.png/webp
    ├── token-ggvi-64.png/webp            gGVI (purple)
    ├── token-ggvi-256.png/webp
    ├── token-igvi-64.png/webp            iGVI (red)
    └── token-igvi-256.png/webp
```

---

## 🎨 Bảng màu thương hiệu

| Token        | Hex       | Dùng cho                      |
|-------------|-----------|-------------------------------|
| Amber Gold  | `#FCB712` | Brand primary / GVI fill      |
| Carbon Dark | `#1C1D1F` | Background / outline stroke   |
| Blue        | `#3B82F6` | sGVI Staking token            |
| Purple      | `#7C5CD8` | gGVI Governance token         |
| Red         | `#EF4444` | iGVI Inverse Bond token       |

---

## 🔄 Tái tạo assets

```bash
# Yêu cầu: rsvg-convert (librsvg2-bin)
sudo apt install librsvg2-bin   # Ubuntu/Debian
cd asset/img
python3 generate.py
```

---

## 📋 Tích hợp HTML — `<head>`

```html
<!-- Favicon chuẩn -->
<link rel="icon" type="image/webp" sizes="32x32" href="/asset/img/favicon-32x32.webp">
<link rel="icon" type="image/webp" sizes="96x96" href="/asset/img/favicon-96x96.webp">
<link rel="apple-touch-icon" sizes="180x180" href="/asset/img/apple-touch-icon-180.webp">

<!-- PWA manifest icons -->
<!-- 192x192 và 512x512 trong manifest.json -->

<!-- Open Graph -->
<meta property="og:image" content="/asset/img/og-image-1200x630.webp">
<meta name="twitter:image" content="/asset/img/twitter-card-800x418.webp">

<!-- MS Tile -->
<meta name="msapplication-TileImage" content="/asset/img/ms-tile-144x144.webp">
<meta name="msapplication-TileColor" content="#1C1D1F">
```
